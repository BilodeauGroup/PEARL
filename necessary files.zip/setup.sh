tleap -f tleap_1mol.in
packmol <packmol_30.in
pdb4amber -i KYFIL_30.pdb -o KYFIL_30_clean.pdb --reduce
tleap -f tleap.in
