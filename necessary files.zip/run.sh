pmemd.cuda -O -i 01_Min.in -o 01_Min.out -p parm7 -c rst7 -r 01_Min.ncrst -inf 01_Min.mdinfo
pmemd.cuda -O -i 02_Min.in -o 02_Min.out -p parm7 -c 01_Min.ncrst -r 02_Min.ncrst -inf 02_Min.mdinfo
pmemd.cuda -O -i 02_Heat.in -o 02_Heat.out -p parm7 -c 02_Min.ncrst -r 02_Heat.ncrst -x 02_Heat.nc -inf 02_Heat.mdinfo
pmemd.cuda -O -i 03_Relax.in -o 03_Relax.out -p parm7 -c 02_Heat.ncrst -r 03_Relax.ncrst -x 03_Relax.nc -inf 03_Relax.mdinfo
pmemd.cuda -O -i 04_Prod.in -o 04_Prod.out -p parm7 -c 03_Relax.ncrst -r 04_Prod.ncrst -x 04_Prod.nc -inf 04_Prod.mdinfo 

